var struct_player =
[
    [ "bank", "struct_player.html#a726bad04edf5c37e6fa0c5b35d3d8fd5", null ],
    [ "bet", "struct_player.html#a485c5647a88538b223036a59f2896642", null ],
    [ "card1", "struct_player.html#ad54463a3ff6b1145bdd275751003f14d", null ],
    [ "card2", "struct_player.html#aadced5e23c348cdc02ba693ddc442c2b", null ],
    [ "hits", "struct_player.html#a337fa6c934d99d50d4d7e0da2380d43d", null ],
    [ "score", "struct_player.html#af90f47d3d6306361df521135f6f1016d", null ]
];