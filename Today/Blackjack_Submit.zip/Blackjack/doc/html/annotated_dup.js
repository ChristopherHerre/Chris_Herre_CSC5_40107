var annotated_dup =
[
    [ "Card", "struct_card.html", "struct_card" ],
    [ "Player", "struct_player.html", "struct_player" ]
];