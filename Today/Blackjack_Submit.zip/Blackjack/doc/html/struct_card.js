var struct_card =
[
    [ "getRank", "struct_card.html#ae9962bedaae46470f4f50296d8dbe3d4", null ],
    [ "getSuit", "struct_card.html#abfb09282f9920c235b464fb7f714b56c", null ],
    [ "getVal", "struct_card.html#a41988c6dbc3695f9cb734cfc0855cf21", null ],
    [ "toString", "struct_card.html#a40725f94d140308b3ec535ad00fd033d", null ],
    [ "cNumber", "struct_card.html#a564ce6f9b22bb66a4055fbf2a7a79347", null ],
    [ "rank", "struct_card.html#a8045fdfbf3c5a7e77276266df90cf9e0", null ],
    [ "suit", "struct_card.html#adbbdc45f711b78c1e08aecfb6e079d3d", null ]
];