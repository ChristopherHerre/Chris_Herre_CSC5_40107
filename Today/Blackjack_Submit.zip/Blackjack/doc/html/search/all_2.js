var searchData=
[
  ['card',['Card',['../struct_card.html',1,'']]],
  ['card1',['card1',['../struct_player.html#ad54463a3ff6b1145bdd275751003f14d',1,'Player']]],
  ['card2',['card2',['../struct_player.html#aadced5e23c348cdc02ba693ddc442c2b',1,'Player']]],
  ['cnumber',['cNumber',['../struct_card.html#a564ce6f9b22bb66a4055fbf2a7a79347',1,'Card']]]
];
