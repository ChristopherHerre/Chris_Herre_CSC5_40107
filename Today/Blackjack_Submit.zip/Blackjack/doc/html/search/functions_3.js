var searchData=
[
  ['getrank',['getRank',['../struct_card.html#ae9962bedaae46470f4f50296d8dbe3d4',1,'Card']]],
  ['getsuit',['getSuit',['../struct_card.html#abfb09282f9920c235b464fb7f714b56c',1,'Card']]],
  ['getval',['getVal',['../struct_card.html#a41988c6dbc3695f9cb734cfc0855cf21',1,'Card']]]
];
