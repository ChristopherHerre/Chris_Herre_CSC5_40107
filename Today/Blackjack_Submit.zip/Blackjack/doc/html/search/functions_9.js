var searchData=
[
  ['tostring',['toString',['../struct_card.html#a40725f94d140308b3ec535ad00fd033d',1,'Card']]]
];
