var searchData=
[
  ['hits',['hits',['../struct_player.html#a337fa6c934d99d50d4d7e0da2380d43d',1,'Player']]]
];
