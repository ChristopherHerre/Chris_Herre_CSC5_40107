var searchData=
[
  ['deal',['deal',['../main_8cpp.html#a40e1340ef0fdb2d20c9e8e1f3c3078b6',1,'main.cpp']]]
];
