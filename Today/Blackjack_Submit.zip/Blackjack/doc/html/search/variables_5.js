var searchData=
[
  ['score',['score',['../struct_player.html#af90f47d3d6306361df521135f6f1016d',1,'Player']]],
  ['suit',['suit',['../struct_card.html#adbbdc45f711b78c1e08aecfb6e079d3d',1,'Card']]]
];
