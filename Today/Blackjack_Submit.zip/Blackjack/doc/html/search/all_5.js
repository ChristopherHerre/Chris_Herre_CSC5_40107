var searchData=
[
  ['hit',['hit',['../main_8cpp.html#a6d4ce378d64b080c059631aad1d29773',1,'main.cpp']]],
  ['hits',['hits',['../struct_player.html#a337fa6c934d99d50d4d7e0da2380d43d',1,'Player']]]
];
