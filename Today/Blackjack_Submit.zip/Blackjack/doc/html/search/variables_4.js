var searchData=
[
  ['rank',['rank',['../struct_card.html#a8045fdfbf3c5a7e77276266df90cf9e0',1,'Card']]]
];
