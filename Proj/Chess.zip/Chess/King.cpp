
/* 
 * File:   King.cpp
 * Author: chris
 * 
 * Created on May 21, 2017, 2:37 PM
 */

#include "King.h"

King::~King()
{
    
}

