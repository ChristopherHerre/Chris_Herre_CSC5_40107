
/* 
 * File:   Rook.cpp
 * Author: chris
 * 
 * Created on May 21, 2017, 1:45 PM
 */

#include "Rook.h"

Rook::~Rook()
{
    
}

