
/* 
 * File:   Pawn.cpp
 * Author: chris
 * 
 * Created on May 19, 2017, 9:26 PM
 */

#include "Pawn.h"

Pawn::~Pawn()
{
    
}

/*void Pawn::move(Piece **all, fstream& f, map<string, int>& m, string input, string input2)
{

    Piece::move(all, f, m, input, input2);
    cout << "PAWN MOVE" << endl;
}*/
