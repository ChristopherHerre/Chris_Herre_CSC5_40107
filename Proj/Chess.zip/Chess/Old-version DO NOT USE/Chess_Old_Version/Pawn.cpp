
/* 
 * File:   Pawn.cpp
 * Author: chris
 * 
 * Created on May 19, 2017, 9:26 PM
 */

#include "Pawn.h"

Pawn::~Pawn()
{
    
}

