var searchData=
[
  ['samesymb',['sameSymb',['../class_piece.html#afc9b134f63e2b3d5891e2ba0699edf95',1,'Piece']]],
  ['setallindex',['setAllIndex',['../main_8cpp.html#ae34c19d5c237a304314afd5ab91a8a2e',1,'main.cpp']]],
  ['setposition',['setPosition',['../class_piece.html#a64c41f989409d75c48949519aa3e7d38',1,'Piece']]],
  ['setsymbol',['setSymbol',['../class_piece.html#ac82f95ec7d998195bdd011a8ee2f3204',1,'Piece']]]
];
