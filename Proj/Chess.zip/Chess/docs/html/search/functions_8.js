var searchData=
[
  ['queen',['Queen',['../class_queen.html#ae2314f4890c7fa7d5da670b3c0b6293b',1,'Queen::Queen()'],['../class_queen.html#aeff77ee1186113902e6cf60ff6a6cd76',1,'Queen::Queen(string position)']]]
];
