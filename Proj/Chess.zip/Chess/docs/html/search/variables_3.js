var searchData=
[
  ['symbol',['symbol',['../class_piece.html#ab1063e521716374d9a97eddf169be096',1,'Piece']]]
];
