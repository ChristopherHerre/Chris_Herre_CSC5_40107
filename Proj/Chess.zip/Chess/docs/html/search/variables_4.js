var searchData=
[
  ['valids',['valids',['../class_piece.html#af96dfaa19d200cac55748774dbb1a56a',1,'Piece']]]
];
