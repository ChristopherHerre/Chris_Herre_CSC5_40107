var searchData=
[
  ['write',['WRITE',['../main_8cpp.html#a0541d25e3bd8e29cd68a0a0a26de76f1',1,'main.cpp']]]
];
