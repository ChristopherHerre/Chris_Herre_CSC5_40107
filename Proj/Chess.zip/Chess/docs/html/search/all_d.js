var searchData=
[
  ['validateinput',['validateInput',['../main_8cpp.html#a908402886673f8a7a5dc4f54e6057602',1,'main.cpp']]],
  ['valids',['valids',['../class_piece.html#af96dfaa19d200cac55748774dbb1a56a',1,'Piece']]]
];
