var searchData=
[
  ['initcoords',['initCoords',['../main_8cpp.html#a6444331b153d596d89373aa8d7e0b59d',1,'main.cpp']]],
  ['initpiece',['initPiece',['../main_8cpp.html#aaed4f7a95c858511e4dc3f56995903b8',1,'initPiece(Piece **type, Piece **all, short size):&#160;main.cpp'],['../main_8cpp.html#ad485d65fa04c45c00b5205f922ff7182',1,'initPiece(Piece **type, Piece **all, short size, short a, short b, short index):&#160;main.cpp']]],
  ['initpieces',['initPieces',['../main_8cpp.html#a7968a1ad5805e21a2719c066ab2bc386',1,'main.cpp']]],
  ['invalid',['invalid',['../_piece_8cpp.html#ac60440d180cc197f8f1e7529fe6cc49d',1,'Piece.cpp']]],
  ['isocc',['isOcc',['../class_piece.html#afbd16578f663257d4dea5beefcdcecb4',1,'Piece']]]
];
