var searchData=
[
  ['availpositions',['availPositions',['../class_piece.html#aba40a894958b12d2e9f2d3b8ac192316',1,'Piece']]]
];
