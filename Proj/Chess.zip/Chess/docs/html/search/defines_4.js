var searchData=
[
  ['magenta',['MAGENTA',['../_colors_8h.html#a6f699060902f800f12aaae150f3a708e',1,'Colors.h']]]
];
