var searchData=
[
  ['king',['King',['../class_king.html',1,'']]],
  ['knight',['Knight',['../class_knight.html',1,'']]]
];
