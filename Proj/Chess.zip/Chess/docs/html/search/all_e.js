var searchData=
[
  ['white',['WHITE',['../_colors_8h.html#a87b537f5fa5c109d3c05c13d6b18f382',1,'Colors.h']]],
  ['write',['WRITE',['../main_8cpp.html#a0541d25e3bd8e29cd68a0a0a26de76f1',1,'main.cpp']]]
];
