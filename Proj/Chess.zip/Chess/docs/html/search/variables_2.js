var searchData=
[
  ['read',['READ',['../main_8cpp.html#acec89b22d9ab6e6b45e9b90207a51a3b',1,'main.cpp']]]
];
