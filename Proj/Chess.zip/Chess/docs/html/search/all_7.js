var searchData=
[
  ['magenta',['MAGENTA',['../_colors_8h.html#a6f699060902f800f12aaae150f3a708e',1,'Colors.h']]],
  ['main',['main',['../main_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main.cpp']]],
  ['main_2ecpp',['main.cpp',['../main_8cpp.html',1,'']]],
  ['main_2eo_2ed',['main.o.d',['../_g_n_u-_linux_2main_8o_8d.html',1,'']]],
  ['main_2eo_2ed',['main.o.d',['../_cygwin-_windows_2main_8o_8d.html',1,'']]],
  ['move',['move',['../class_piece.html#af60f38fc97d33416b6286d5e74c33778',1,'Piece']]]
];
