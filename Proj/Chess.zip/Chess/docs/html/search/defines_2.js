var searchData=
[
  ['green',['GREEN',['../_colors_8h.html#acfbc006ea433ad708fdee3e82996e721',1,'Colors.h']]]
];
