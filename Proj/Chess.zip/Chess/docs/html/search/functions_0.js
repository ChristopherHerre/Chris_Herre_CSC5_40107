var searchData=
[
  ['bishop',['Bishop',['../class_bishop.html#af4568da25142a681c699ee046e3a630b',1,'Bishop::Bishop()'],['../class_bishop.html#adf07e0993c6cc5b99aa326cde0e32e95',1,'Bishop::Bishop(string position)']]]
];
