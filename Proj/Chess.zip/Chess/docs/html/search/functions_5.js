var searchData=
[
  ['king',['King',['../class_king.html#ae374efc047c95212f78a49c877e34563',1,'King::King()'],['../class_king.html#a3bc5b94579c5895795a55f1ce7a796f4',1,'King::King(string position)']]],
  ['knight',['Knight',['../class_knight.html#aa5c98808cbb05f2772bc3a32ef859387',1,'Knight::Knight()'],['../class_knight.html#ae6d6c2e4445aea841a368e2346479481',1,'Knight::Knight(string position)']]]
];
