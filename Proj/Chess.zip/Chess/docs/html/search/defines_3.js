var searchData=
[
  ['inverse',['INVERSE',['../_colors_8h.html#ade269cc47cfaba70068f2586e898051d',1,'Colors.h']]]
];
