var searchData=
[
  ['refreshboard',['refreshBoard',['../main_8cpp.html#a460fb296898806fec6667a62a14676cb',1,'main.cpp']]],
  ['removeinvalids',['removeInvalids',['../class_piece.html#a4e89ae7011b06d46dc4ba76b6f676791',1,'Piece']]],
  ['rmvsamesymb',['rmvSameSymb',['../class_piece.html#a5af40f3573b8963bdd202a750268c3e9',1,'Piece']]],
  ['rook',['Rook',['../class_rook.html#a0cce560130c640f82c99937ce5781ac1',1,'Rook::Rook()'],['../class_rook.html#a5bb2e3899dc49bd53ba8428be36cc153',1,'Rook::Rook(string position)']]]
];
