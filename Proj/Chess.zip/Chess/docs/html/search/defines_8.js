var searchData=
[
  ['yellow',['YELLOW',['../_colors_8h.html#abf681265909adf3d3e8116c93c0ba179',1,'Colors.h']]]
];
