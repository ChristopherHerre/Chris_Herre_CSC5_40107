

/* 
 * File:   Knight.cpp
 * Author: chris
 * 
 * Created on May 21, 2017, 12:24 PM
 */

#include "Knight.h"

Knight::~Knight()
{
    
}

