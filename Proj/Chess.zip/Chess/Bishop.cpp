
/* 
 * File:   Bishop.cpp
 * Author: chris
 * 
 * Created on May 21, 2017, 1:15 PM
 */

#include "Bishop.h"

Bishop::~Bishop()
{
    
}

