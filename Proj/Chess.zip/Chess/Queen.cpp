
/* 
 * File:   Queen.cpp
 * Author: chris
 * 
 * Created on May 21, 2017, 2:46 PM
 */

#include "Queen.h"

Queen::~Queen()
{
    
}

